from externals.hachoir.metadata.metadata import extractMetadata  # noqa

# Just import the module,
# each module use registerExtractor() method
import externals.hachoir.metadata.archive  # noqa
import externals.hachoir.metadata.audio  # noqa
import externals.hachoir.metadata.file_system  # noqa
import externals.hachoir.metadata.image  # noqa
import externals.hachoir.metadata.jpeg  # noqa
import externals.hachoir.metadata.misc  # noqa
import externals.hachoir.metadata.program  # noqa
import externals.hachoir.metadata.riff  # noqa
import externals.hachoir.metadata.video  # noqa
import externals.hachoir.metadata.cr2 # noqa